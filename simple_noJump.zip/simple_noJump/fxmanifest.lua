fx_version 'bodacious'
games { 'gta5' }

author '_badlad'

description 'Simple noJump'

version '1.0'

client_script 'client.lua'